from django.apps import AppConfig


class DatasetConfig(AppConfig):
    name = 'Dataset'
