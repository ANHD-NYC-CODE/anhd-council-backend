from app.settings.base import *
DEBUG = True


ADMINS = (
    # ('Dev', 'anhd.tech@gmail.com'),
    # ('Jack T. (Conceptual)', 'jack@conceptu.al'),
    # add yours here too!
)

CACHE_MIDDLEWARE_ANONYMOUS_ONLY = True

# Dummy cache for dev use
# CACHES = {
#     'default': {
#         'BACKEND': 'django.core.cache.backends.dummy.DummyCache'
#     }
# }
