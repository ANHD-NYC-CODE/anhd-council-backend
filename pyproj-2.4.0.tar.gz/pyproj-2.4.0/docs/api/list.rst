Lists
=====


pyproj.get_proj_operations_map
------------------------------

.. autofunction:: pyproj.get_proj_operations_map


pyproj.get_ellps_map
--------------------

.. autofunction:: pyproj.get_ellps_map


pyproj.get_prime_meridians_map
------------------------------

.. autofunction:: pyproj.get_prime_meridians_map


pyproj.get_units_map
--------------------

.. autofunction:: pyproj.get_units_map


pyproj.get_angular_units_map
----------------------------

.. autofunction:: pyproj.get_angular_units_map


pyproj.get_authorities
----------------------

.. autofunction:: pyproj.get_authorities


pyproj.get_codes
----------------

.. autofunction:: pyproj.get_codes
