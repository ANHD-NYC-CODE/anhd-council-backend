Exceptions
==========

.. automodule:: pyproj.exceptions
    :members:
