Geod
====

pyproj.Geod
-----------

.. autoclass:: pyproj.Geod
    :members:
    :show-inheritance:
    :inherited-members:
    :special-members: __init__
