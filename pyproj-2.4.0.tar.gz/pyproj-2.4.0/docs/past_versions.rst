Documentation Archive
=====================

- `2.4.0 <https://pyproj4.github.io/pyproj/v2.4.0rel/>`_
- `2.3.1 <https://pyproj4.github.io/pyproj/v2.3.1rel/>`_
- `2.3.0 <https://pyproj4.github.io/pyproj/v2.3.0rel/>`_
- `2.2.2 <https://pyproj4.github.io/pyproj/v2.2.2rel/>`_
- `2.2.1 <https://pyproj4.github.io/pyproj/v2.2.1rel/>`_
- `2.2.0 <https://pyproj4.github.io/pyproj/v2.2.0rel/>`_
- `2.1.3 <https://pyproj4.github.io/pyproj/v2.1.3rel/>`_
