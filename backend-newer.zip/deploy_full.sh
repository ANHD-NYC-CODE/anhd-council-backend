ssh -t anhd@45.55.44.160 "cd /var/www/anhd-council-backend && sudo git pull origin master && sudo sh recreate.prod.sh"
