docker exec -it nginx_server nginx -s reload
